let uploadedImage = null;

document.getElementById("uploadImage").addEventListener("change", function(event) {

    const file = event.target.files[0];

    if (!file) return;

    const reader = new FileReader();

    reader.onload = function(e) {

        uploadedImage = new Image();

        uploadedImage.src = e.target.result;

        uploadedImage.onload = function() {

            document.getElementById("canvas").style.display = "none";

            document.getElementById("downloadBtn").style.display = "none";

        };

    };

    reader.readAsDataURL(file);

});

document.getElementById("convertBtn").addEventListener("click", function() {

    if (!uploadedImage) {

        alert("Please upload an image first!");

        return;

    }

    const canvas = document.getElementById("canvas");

    const ctx = canvas.getContext("2d");

    canvas.width = uploadedImage.width;

    canvas.height = uploadedImage.height;

    ctx.drawImage(uploadedImage, 0, 0);

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

    const pixels = imageData.data;

    for (let i = 0; i < pixels.length; i += 4) {

        const gray = 0.3 * pixels[i] + 0.59 * pixels[i + 1] + 0.11 * pixels[i + 2];

        pixels[i] = pixels[i + 1] = pixels[i + 2] = gray;

    }

    ctx.putImageData(imageData, 0, 0);

    canvas.style.display = "block";

    const downloadBtn = document.getElementById("downloadBtn");

    downloadBtn.style.display = "inline-block";

    downloadBtn.onclick = function() {

        const link = document.createElement("a");

        link.download = "monochrome_image.png";

        link.href = canvas.toDataURL("image/png");

        link.click();

    };

});
